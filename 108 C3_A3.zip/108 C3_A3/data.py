#############################################################################
# Put data here to us as test data, wwhile database connection is set up
############################################################################

mock_data = [
    {
        "id": 1,
        "price": 12.40,
        "stock": 13,
        "title": "pineapple",
        "image":  "pineapple.jpg",
        "discount": 2.2,
        "category": "Fruit"
    },

    {
        "id": 2,
        "price": 5,
        "stock": 4,
        "title": "banana",
        "image":  "banana.png",
        "discount": 0.5,
        "category": "Fruit"
    },

    {
        "id": 3,
        "price": 1.12,
        "stock": 141,
        "title": "Brocoly",
        "image": "brocolli.jpg",
        "discount": 0.2,
        "category": "vegetable"
    },

    {
        "id": 4,
        "price": 200,
        "stock": 12,
        "title": "Rib eye",
        "image": "rib-eye.jpg",
        "discount": 10,
        "category": "meat"
    },


    {
        "id": 5,
        "price": 59,
        "stock": 53,
        "title": "Sirloin",
        "image": "sirloin.jpg",
        "discount": 5,
        "category": "meat"
    }
]
