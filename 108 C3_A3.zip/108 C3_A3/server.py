from unittest import mock
from flask import Flask
from about import me
from data import mock_data
import json


app = Flask("server")


@app.get("/")
def home():
    return "Hello from Flask!"


@app.get("/test")
def test():
    return "This is just a simple test!"


@app.get("/about")
def about():
    return "My name is Mario"


############################################################################
# API ENDPOINTS = PRODUCTS
############################################################################

@app.get("/api/version")
def version():
    return "1.0"


@app.get("/api/about")
def about_me():
    return json.dumps(me)
# return f'{me["first"]} {me["last"]}'


########################################################################
## get /api/products
# return mock_data as json string
########################################################################
@app.get("/api/products")
def products():
    return json.dumps(mock_data)


@app.get("/api/products/<id>")
def get_products_by_id(id):
    for prod in mock_data:
        if str(prod["id"]) == id:
            return json.dumps(prod)

    return "Not found"


app.run(debug=True)
